
export default function Blog(){
    return(
        <main>
            <h1>Blog</h1>
        </main>
    )
}