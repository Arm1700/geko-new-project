
export default function Terminates(){
    return(
        <main>
            <h1>Terminates</h1>
        </main>
    )
}