const tutorsArray = [
  {
    id: 1,
    image: 'https://eduma.thimpress.com/wp-content/uploads/2015/11/team-1.jpg',
    name: 'Susan Jackson',
    role: 'Frontend Develoer',
  },
  {
    id: 2,
    image: 'https://eduma.thimpress.com/wp-content/uploads/2015/11/team-3.jpg',
    name: 'Manuel',
    role: 'Fullstack Developer',
  },
  {
    id: 3,
    image: 'https://eduma.thimpress.com/wp-content/uploads/2015/11/team-5.jpg',
    name: 'John Doe',
    role: 'Backend Developer',
  },
  {
    id: 4,
    image: 'https://eduma.thimpress.com/wp-content/uploads/2015/11/team-7.jpg',
    name: 'Elsie',
    role: 'Designer',
  },
  {
    id: 5,
    image: 'https://eduma.thimpress.com/wp-content/uploads/2015/11/team-6.jpg',
    name: 'Anthony',
    role: 'Data Scientist',
  },
];

export default tutorsArray;
